import os
import PyPDF2

def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text

def process_pdfs(input_root, output_root):
    os.makedirs(output_root, exist_ok=True)
    
    for company in ["MSFT", "AAPL"]:
        company_path = os.path.join(input_root, company)
        if os.path.isdir(company_path):
            for year in os.listdir(company_path):
                year_path = os.path.join(company_path, year)
                if os.path.isdir(year_path):
                    output_dir = os.path.join(output_root, company, year)
                    os.makedirs(output_dir, exist_ok=True)
                    
                    for filename in os.listdir(year_path):
                        if filename.endswith(".pdf"):
                            pdf_path = os.path.join(year_path, filename)
                            text = extract_text_from_pdf(pdf_path)
                            
                            output_file = os.path.join(output_dir, filename.replace(".pdf", ".txt"))
                            with open(output_file, "w") as f:
                                f.write(text)

if __name__ == "__main__":
    process_pdfs("rag_datasets_subset", "output_text")
