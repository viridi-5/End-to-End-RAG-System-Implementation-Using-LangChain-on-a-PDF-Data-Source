import os
import glob
import json
import time
from dotenv import load_dotenv
from pinecone import Pinecone, ServerlessSpec
from sentence_transformers import SentenceTransformer
from PyPDF2 import PdfReader
import pdfplumber
import pandas as pd

# Load environment variables (ensure you store API keys safely)
load_dotenv()
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
INDEX_NAME = "financial-docs"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Initialize Pinecone client
pc = Pinecone(api_key=PINECONE_API_KEY)

# Create index if it doesn't exist
if INDEX_NAME not in pc.list_indexes().names():
    pc.create_index(
        name=INDEX_NAME,
        dimension=384,
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1"),
    )

# Connect to the index
index = pc.Index(INDEX_NAME)

# Initialize embedding model
model = SentenceTransformer(EMBEDDING_MODEL)

# Define PDF directory structure
pdf_dir = "rag_datasets_subset"
companies = ["MSFT", "AAPL"]
years = ["2016", "2017", "2018"]

def extract_text_from_pdf(pdf_path):
    """Extract text from PDF using PyPDF2 with fallback to pdfplumber."""
    text = ""
    try:
        with open(pdf_path, "rb") as file:
            reader = PdfReader(file)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:  # Ensure it's not empty
                    text += page_text + "\n"
    except Exception as e:
        print(f"Error extracting text from {pdf_path} using PyPDF2: {e}")

    if not text:  # Fallback to pdfplumber if PyPDF2 fails
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""  # Ensure no None values
    return text.strip()

def extract_tables_from_pdf(pdf_path):
    """Extract tables from PDF using pdfplumber."""
    tables = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                extracted_tables = page.extract_tables()
                for table in extracted_tables:
                    df = pd.DataFrame(table)
                    tables.append(df.to_json())  # Convert to JSON format
    except Exception as e:
        print(f"Error extracting tables from {pdf_path}: {e}")
    return tables

def chunk_text(text, chunk_size=500):
    """Break text into smaller chunks for embedding."""
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

# Process all PDFs
for company in companies:
    for year in years:
        folder_path = os.path.join(pdf_dir, company, year)
        pdf_files = glob.glob(os.path.join(folder_path, "*.pdf"))

        for pdf_file in pdf_files:
            print(f"Processing: {pdf_file}")

            # Extract text and tables
            text = extract_text_from_pdf(pdf_file)
            tables = extract_tables_from_pdf(pdf_file)
            combined_content = text + "\n".join(tables)

            # Skip if no extractable content
            if not combined_content.strip():
                print(f"Skipping {pdf_file} - No content extracted.")
                continue

            # Generate embeddings
            text_chunks = chunk_text(combined_content)
            embeddings = model.encode(text_chunks, show_progress_bar=True)

            # Upsert embeddings in batches
            batch_size = 10
            for i in range(0, len(embeddings), batch_size):
                batch = embeddings[i:i + batch_size]
                ids = [f"{company}_{year}_{os.path.basename(pdf_file)}_{i+j}" for j in range(len(batch))]
                try:
                    index.upsert(vectors=list(zip(ids, [vec.tolist() for vec in batch])))
                except Exception as e:
                    print(f"Error uploading batch {i} for {pdf_file}: {e}")
                    time.sleep(5)  # Wait before retrying

            print(f"Uploaded {len(embeddings)} embeddings for {pdf_file}")

print("Processing completed.")
