import os

def chunk_text(text, chunk_size=500):
    words = text.split()
    return [" ".join(words[i : i + chunk_size]) for i in range(0, len(words), chunk_size)]

def process_text_files(input_root, output_root):
    os.makedirs(output_root, exist_ok=True)

    for company in ["MSFT", "AAPL"]:
        company_path = os.path.join(input_root, company)
        if os.path.isdir(company_path):
            for year in os.listdir(company_path):
                year_path = os.path.join(company_path, year)
                if os.path.isdir(year_path):
                    output_dir = os.path.join(output_root, company, year)
                    os.makedirs(output_dir, exist_ok=True)

                    for filename in os.listdir(year_path):
                        if filename.endswith(".txt"):
                            with open(os.path.join(year_path, filename), "r") as f:
                                text = f.read()
                            chunks = chunk_text(text)

                            for i, chunk in enumerate(chunks):
                                with open(os.path.join(output_dir, f"{filename.replace('.txt', '')}_chunk_{i}.txt"), "w") as f:
                                    f.write(chunk)

if __name__ == "__main__":
    process_text_files("cleaned_text", "segmented_text")
