import os
import openai
from pinecone import Pinecone
from dotenv import load_dotenv  # Import dotenv

# Load environment variables from .env file
load_dotenv()

# Fetch API Keys
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
INDEX_NAME = "financial-docs"

# Validate API keys
if not OPENAI_API_KEY:
    raise ValueError("Missing OpenAI API Key. Ensure it's set in your .env file.")

if not PINECONE_API_KEY:
    raise ValueError("Missing Pinecone API Key. Ensure it's set in your .env file.")

# Initialize Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY)
index = pc.Index(INDEX_NAME)

# Function to get OpenAI embeddings
def get_openai_embedding(text):
    """Generate embeddings using OpenAI's free model."""
    openai.api_key = OPENAI_API_KEY  # Set API key
    response = openai.embeddings.create(
        input=text,
        model="text-embedding-3-small"  # Free model
    )
    return response.data[0].embedding

# Function to query Pinecone
def query_pinecone(query_text, top_k=3):
    """Search Pinecone index using OpenAI-generated embeddings."""
    query_embedding = get_openai_embedding(query_text)
    response = index.query(vector=query_embedding, top_k=top_k, include_metadata=True)

    results = []
    for match in response['matches']:
        content = match.get("metadata", {}).get("content", "No content found")
        results.append(f"Score: {match['score']}\n{content}\n")

    return results if results else ["No relevant information found."]

# Read questions from text file
questions_file = "questions.txt"
with open(questions_file, "r") as f:
    questions = f.readlines()

# Process each question and store responses
responses = []
for idx, question in enumerate(questions):
    question = question.strip()
    print(f"Querying: {question}")

    answers = query_pinecone(question)
    response_text = f"Q{idx+1}: {question}\n" + "\n".join(answers) + "\n\n"
    responses.append(response_text)

# Save responses to a text file
output_file = "responses.txt"
with open(output_file, "w") as f:
    f.writelines(responses)

print(f"Responses saved to {output_file}")
