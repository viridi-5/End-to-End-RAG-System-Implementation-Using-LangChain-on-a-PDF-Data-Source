import os
import re

def clean_text(text):
    text = re.sub(r"\n+", "\n", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\(cid:\d+\)", "", text)
    return text.strip()

def process_text_files(input_root, output_root):
    os.makedirs(output_root, exist_ok=True)

    for company in ["MSFT", "AAPL"]:
        company_path = os.path.join(input_root, company)
        if os.path.isdir(company_path):
            for year in os.listdir(company_path):
                year_path = os.path.join(company_path, year)
                if os.path.isdir(year_path):
                    output_dir = os.path.join(output_root, company, year)
                    os.makedirs(output_dir, exist_ok=True)

                    for filename in os.listdir(year_path):
                        if filename.endswith(".txt"):
                            with open(os.path.join(year_path, filename), "r") as f:
                                text = f.read()
                            cleaned_text = clean_text(text)

                            with open(os.path.join(output_dir, filename), "w") as f:
                                f.write(cleaned_text)

if __name__ == "__main__":
    process_text_files("output_text", "cleaned_text")
