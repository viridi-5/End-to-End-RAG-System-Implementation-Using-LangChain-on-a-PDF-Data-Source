import os
import pandas as pd
import pdfplumber
import camelot

def extract_tables_from_pdf(pdf_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    tables = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            extracted_tables = page.extract_tables()
            tables.extend(extracted_tables)

    for i, table in enumerate(tables):
        df = pd.DataFrame(table)
        df.to_csv(os.path.join(output_dir, f"{os.path.basename(pdf_path)}_table_{i}.csv"), index=False)

    try:
        camelot_tables = camelot.read_pdf(pdf_path, pages="all", flavor="stream")
        for i, table in enumerate(camelot_tables):
            df = table.df
            df.to_csv(os.path.join(output_dir, f"{os.path.basename(pdf_path)}_camelot_table_{i}.csv"), index=False)
    except:
        pass

def process_pdfs(input_root, output_root):
    os.makedirs(output_root, exist_ok=True)

    for company in ["MSFT", "AAPL"]:
        company_path = os.path.join(input_root, company)
        if os.path.isdir(company_path):
            for year in os.listdir(company_path):
                year_path = os.path.join(company_path, year)
                if os.path.isdir(year_path):
                    output_dir = os.path.join(output_root, company, year)
                    os.makedirs(output_dir, exist_ok=True)

                    for filename in os.listdir(year_path):
                        if filename.endswith(".pdf"):
                            extract_tables_from_pdf(os.path.join(year_path, filename), output_dir)

if __name__ == "__main__":
    process_pdfs("rag_datasets_subset", "output_tables")
